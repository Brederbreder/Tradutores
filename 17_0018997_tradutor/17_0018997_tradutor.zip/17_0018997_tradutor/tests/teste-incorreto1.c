int funcao(int x){
    int a;
    if(x > 100){
        a = 1;
    } else {
        a = 0;
    }
    return a;
}

int main(){
    int a;
    int b;
    funcao_nao_declarada(a,b);
    int list aa;
    float list bb;
    if(a > aa){
        b = 10;
    }
    float e;
    float f;
    int c;
    c = a b;
    float d;
    d = e f;
    return 0;
}