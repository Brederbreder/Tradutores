int main() {
    int a;
    float b;
    int list c;
    float list d;
    int e;
    return 0;
}